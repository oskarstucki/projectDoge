<?php

session_start();
require_once("utils.php");

site();


if($_GET["p"] === "add"){
    require("adder.php");

}
else if($_GET["p"] === "remove"){

} else{
    require("adder.php");

}

notes();