<?php
/**
 * Created by PhpStorm.
 * User: oskar
 * Date: 10/22/17
 * Time: 4:41 AM
 */

require_once("utils.php");

if(isset($_POST["note"])) {
    $db = new PDO('mysql:host=localhost;dbname=www;charset=utf8', 'www', 'asd');


    $stmt = $db->prepare("INSERT INTO notes(note, timeanddate) VALUES(:f1, :f2)");
    $date = new DateTime();
    $stamp= date("Y-m-d H:i:s", $date->getTimestamp());

    $stmt->execute(array(":f1" => $_POST["note"], ":f2" => $stamp));

    $rows = $stmt->fetchAll();
    header("Location: index.php");
    exit;
}
else {
    print <<<LOGINFORM
    <div class="form">
    <h2>uusi asia</h2>
    <form action="index.php?p=add" method="post">
    <input class="newThings" title="newThing" type="text" name="note">
    <input class="subbut" type="submit" value="send">
    </form>
    </div>
LOGINFORM;
}