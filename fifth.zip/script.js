$(document).ready(function () {
    let input = $(".newThings");
    let list = $("#list");
    let elementNumber=0;

    $("#append").on("click", function () {
        list.append("<li>"+input.val()+"</li>");
        input.val("")
    });

    list.on("mouseenter","li", function () {
        $(this).addClass("inside")
    });

    list.on("mouseleave","li", function () {
        $(this).removeClass("inside")
    });

    list.on("click", "button", function () {
        $( this).parent("li").fadeOut(function(){ $( this ).parent("li").remove(); });
    });


});